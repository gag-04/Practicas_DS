
class Target {
  int execute(String data){
    return 0;
  }
}